# excode 0.0.0.9000

* This is the inital release of excode (development version), which provides code for excess count detection in epidemiological time series.
