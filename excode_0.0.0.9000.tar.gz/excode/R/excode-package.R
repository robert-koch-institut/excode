#' @keywords internal
#' @aliases excode-package
#' @import surveillance
#' @import MASS
#' @import methods
#' @import graphics
#' @import stats
#' @import splines
"_PACKAGE"
